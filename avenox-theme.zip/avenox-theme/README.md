# AvenoxTheme

> Minecraft End theme for Pterodactyl / Reviactyl Panel.

---

## Install

```bash
bash <(curl -sL https://raw.githubusercontent.com/YOUR_USERNAME/avenox-theme/main/install.sh)
```

## Uninstall

```bash
bash <(curl -sL https://raw.githubusercontent.com/YOUR_USERNAME/avenox-theme/main/uninstall.sh)
```
